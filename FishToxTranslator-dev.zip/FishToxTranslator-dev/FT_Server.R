FT_Server <- function(input, output, session) {
  
  observe_helpers(session = shiny::getDefaultReactiveDomain(),
                  help_dir = "helpfiles", withMathJax = FALSE)
  
  source("Baseline_Tab_Events_Server.R", local = TRUE)
  source("Stressor_Tab_Events_Server.R", local = TRUE)
  source("DownloadScenario_Tab_Events_Server.R", local = TRUE)
  source("DownloadResults_Tab_Events_Server.R", local = TRUE)
  source("DeleteScenario_Tab_Events_Server.R", local = TRUE)
  source("DeleteResults_Tab_Events_Server.R", local = TRUE)
  source("ImportScenario_Tab_Events_Server.R", local = TRUE)
  source("ImportResults_Tab_Events_Server.R", local = TRUE)
  source("Visualize_Tab_Events_Server.R", local = TRUE)
  source("Run_Tab_Events_Server.R", local = TRUE)
  source("Results_Tab_Events_Server.R", local = TRUE)
  source("Reset_App.R", local = TRUE)

  keep_alive <- shiny::reactiveTimer(intervalMs = 10000, session = shiny::getDefaultReactiveDomain())
  shiny::observe({keep_alive()})
  
}

    
  
    
  
    
      
   
  
              
  
  
