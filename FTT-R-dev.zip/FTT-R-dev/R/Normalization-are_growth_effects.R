##~             ,''''''''''''''.
##~~           /   USEPA FISH   \
##~   >~',*>  <  TOX TRANSLATOR  )
##~~           \ v1.0 'Doloris' /
##~             `..............'
##~~
##~  N. Pollesch - pollesch.nathan@epa.gov

#### Header Info ####
## Normalization Functions for Parameter,  are_growth_effects 

## Information from parameters_master.RData
# t(FishToxTranslator::parameters_master[ 39 ,]) #Uncomment to pull data from package into R

#### Derivation Notes: ####

#### Example Normalizations: ####
